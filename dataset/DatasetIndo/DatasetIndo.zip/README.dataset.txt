# Dermatitis Atopic Detection > 2025-01-30 8:22am
https://universe.roboflow.com/eczema-detection/dermatitis-atopic-detection

Provided by a Roboflow user
License: undefined

